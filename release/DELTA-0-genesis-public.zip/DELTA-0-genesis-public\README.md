﻿# DELTA-0 Genesis Release Candidate

DELTA is an open, zero-token cryptographic protocol for proving digital change.

DELTA is not a cryptocurrency.
DELTA is not a token.
DELTA is not an NFT project.
DELTA is not a blockchain-dependent application.
DELTA is not a SaaS platform.

Core statement:

The internet can prove ownership.
DELTA proves change.

Precise technical statement:

DELTA creates cryptographically signed, hash-bound, tamper-evident records of declared and verified digital change.

---

## Package contents

This package contains the DELTA-0 Genesis public artifacts.

The Genesis Record demonstrates the first complete DELTA-0 proof flow:

Delta Claim
→ Delta Attestation
→ Ledger Entry
→ Signed Checkpoint
→ Public Verification

Included folders:

spec/
src/
genesis/

Included important files:

spec/DELTA-0-v0.5.2-core-structures.md
src/genesis_generator.py
src/genesis_public_verifier.py
genesis/claim.json
genesis/executor_signature.json
genesis/attestation.json
genesis/verifier_signature.json
genesis/ledger_entry.json
genesis/ledger.json
genesis/chain_proof.json
genesis/checkpoint.json
genesis/checkpoint_signature.json
genesis/genesis_bundle.json
genesis/evidence_manifest.json
genesis/verification_policy.json
genesis/public_keys.json
genesis/hashes.txt

The file genesis/SELF_CHECK_OK.txt is only a local generator log.
It is not treated as cryptographic proof.

The real proof is produced by independently verifying the public JSON artifacts, hashes, signatures, ledger entry, chain proof, and checkpoint.

---

## Private keys

Private keys are not included in this public package.

The original local development environment generated private keys in:

genesis/private_keys/

That folder is intentionally excluded.

Do not publish private keys.
Do not commit private keys.
Do not share private keys.

The public verifier checks that the package does not contain:

private_keys
.pem
.key
.secret
.env

---

## How to verify

Install Python 3.12 or newer.

Install the required cryptography package:

python -m pip install cryptography

Run the public verifier from inside the extracted package:

python .\src\genesis_public_verifier.py

Expected final result:

DELTA PUBLIC VERIFIER RESULT: OK

---

## What the public verifier checks

The verifier checks:

1. The public package does not contain private keys.
2. JSON objects are loaded and canonicalized before hashing.
3. Hashes use sha256:<64 lowercase hex chars>.
4. Delta Claim hash is recomputed.
5. Executor signature verifies against the Delta Claim.
6. Delta Attestation hash is recomputed.
7. Verifier signature verifies against the Delta Attestation.
8. Ledger Entry binds:
   - claim_hash
   - executor_sig_hash
   - attestation_hash
   - verifier_sig_hash
9. Genesis prev_entry_hash uses the fixed zero hash.
10. Checkpoint head_entry_hash matches the Ledger Entry hash.
11. Checkpoint signature verifies.
12. Chain proof links the Ledger Entry to the checkpoint.
13. Genesis bundle hash summary matches recomputed hashes.
14. hashes.txt matches recomputed hashes.
15. SELF_CHECK_OK.txt is ignored as proof.

---

## Cryptographic model

DELTA-0 uses:

- JSON Canonicalization Scheme / JCS-style canonical JSON
- SHA-256 hashes
- Ed25519 signatures
- detached signature envelopes
- linear hash-chain
- signed checkpoints
- private evidence hashes

Rule:

Hash identifies the object.
Signature signs the canonical object.

Signatures are not embedded inside the objects they sign.
This avoids circular hashing and signature ambiguity.

---

## Genesis purpose

The DELTA Genesis Record symbolically records the creation of the first public Proof of Change structure.

Before:
The internet could prove ownership, identity, transactions, and file hashes,
but had no universal proof layer for change.

Action:
DELTA-0 protocol genesis release created.

After:
The first DELTA Proof of Change record exists.

Evidence:
Protocol specification hash, generator source hash, before statement hash,
after statement hash, and verification policy hash.

Verifier:
Genesis local verifier key.

---

## What DELTA_VERIFIED means

In this Genesis package, DELTA_VERIFIED means that the following are cryptographically consistent:

- Delta Claim
- Executor signature
- Delta Attestation
- Verifier signature
- Ledger Entry
- Chain proof
- Signed Checkpoint
- Checkpoint signature
- Genesis bundle hash summary

It means the declared change, evidence hash, signatures, ledger entry, and checkpoint are cryptographically bound and tamper-evident.

---

## What DELTA_VERIFIED does not mean

DELTA_VERIFIED does not mean:

- absolute truth about the physical world
- that the verifier cannot be wrong
- that evidence is publicly visible
- that evidence could not have been fabricated before hashing
- legal ownership
- financial value
- token ownership
- cryptocurrency issuance

DELTA is not a magic truth machine.

DELTA proves a cryptographically bound record of a declared and verified change.

---

## Distribution hash

The ZIP file hash is a distribution checksum.

It is useful for checking that the downloaded package was not corrupted or replaced.

The ZIP hash is not part of the internal DELTA-0 protocol proof.

The internal proof is based on the public JSON artifacts, canonical hashes, signatures, ledger entry, chain proof, and signed checkpoint.

---

## Release status

DELTA-0 Genesis Release Candidate

Protocol version:

DELTA-0 v0.5.2

Status:

Public verifier OK
Private keys not included
Zero-token protocol
Non-cryptocurrency
Proof of Change
